#!/bin/bash
npm start
